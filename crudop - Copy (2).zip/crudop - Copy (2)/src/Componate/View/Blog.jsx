import React, { useState } from 'react'
import { database } from './Config'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';



function Blog() {

  const [blogs, setblogs] = useState(database)
  const [edit, setblogedit] = useState(database)


  ///modall
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // modal end


  const handleDelete = async (id) => {
    const a = await axios.delete(`https://crudop-b5bdd-default-rtdb.asia-southeast1.firebasedatabase.app/blog/${id}.json`)
    console.log(a);
  };

  return (
    <div>
      <div className="container">
        <div className="row">
          {
            blogs?.map((blog, index) =>
              <div key={index} className='col-3 mt-4 '>
                <Card style={{ width: '18rem' }}>
                  <Card.Img variant="top" src="https://wallpaperaccess.com/full/3078918.jpg" />
                  <Card.Body>
                    <Card.Title>{blog.Title}</Card.Title>
                    <Card.Text>
                      {blog.Description}
                    </Card.Text>
                    <Button variant="primary" className='me-3 px-4' onClick={handleShow}>Edit</Button>
                    <Button variant="danger" className=' px-4' onClick={() => handleDelete(blog?.id)}>Delete</Button>
                  </Card.Body>
                </Card>

              </div>
            )
          }

        </div>
      </div>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default Blog
