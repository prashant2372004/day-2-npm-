import React, { useState } from 'react'
import { blogob } from './Config'
import { database } from './Config'
// import { v4 as uuidv4 } from 'uuid';
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";

import axios from 'axios';


function Addblog() {
    const navigate = useNavigate()
    const [Blog, setBlog] = useState(blogob)
    const { Title, Description } = Blog

    const handelchange = (e) => {
        setBlog({ ...Blog, [e.target.name]: e.target.value })

    }
    const handelsubmit = async (e) => {
        e.preventDefault()

        if (!Blog.Title || !Blog.Description) {
            toast.error("Plase Submit Data")
        }
        else {
            await axios.post("https://crudop-b5bdd-default-rtdb.asia-southeast1.firebasedatabase.app/blog.json", Blog)

            const respone = await axios.get("https://crudop-b5bdd-default-rtdb.asia-southeast1.firebasedatabase.app/blog.json")

            database.push({ ...Blog, Date: new Date() })
            console.log(database);

            const value = Object.values(respone?.data);
            const key = Object.keys(respone?.data);

            key?.map((element, index) => (value[index].id = element));
            setBlog(value)

        
            toast.success("Data is Successfuly Submited")

            console.log(respone);
            navigate("/blog")
        }
    }
    return (
        <div className='container'>
            <form on onSubmit={handelsubmit}>
                <div className="mb-3">
                    <label htmlFor="exampleInputEmail1" className="form-label">Title</label>
                    <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={handelchange} name='Title' value={Title} />

                </div>
                <div className="mb-3">
                    <label htmlFor="exampleInputPassword1" className="form-label">Description</label>
                    <input type="text" className="form-control" id="exampleInputPassword1" onChange={handelchange} name='Description' value={Description} />
                </div>
                <div className='d-flex justify-content-center'>
                    <button type="submit" className="btn btn-dark px-5 py-2 x" >Submit</button>
                </div>
            </form>
        </div>
    )
}

export default Addblog
