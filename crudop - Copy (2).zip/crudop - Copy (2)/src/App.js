import React, { Suspense } from 'react'
import { Route, Routes } from 'react-router-dom'

const Navbar = React.lazy(() => import("./Componate/Global/Navbar/Navbar"))
const Home = React.lazy(() => import("./Componate/View/Home"))
const Blog = React.lazy(() => import("./Componate/View/Blog"))
const Addblog = React.lazy(() => import("./Componate/View/Addblog"))

function App() {
  return (
    <>
      <Suspense fallback={<>Hellow World</>}>
        <Navbar/>
        <Routes>
          <Route  path='/' element={<Home/>}/>
          <Route  path='/blog' element={<Blog/>}/>
          <Route  path='/addblog' element={<Addblog/>}/>
        </Routes>
      </Suspense>
    </>
  )
}

export default App
