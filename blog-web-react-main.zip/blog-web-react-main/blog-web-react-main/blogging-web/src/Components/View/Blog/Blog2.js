import React, { useState } from 'react';

function Blog2() {
  const [text, setText] = useState('');
  const handleTextChange = (e) => {
    setText(e.target.value);
  };
  
  const handleUpperChange = () => {
    let newtext = text.toUpperCase()
    setText(newtext);
  };
  const handleUpperChange2 = () => {
    let newtext = text.toLocaleLowerCase()
    setText(newtext);
  };
  const handleUpperChange3 = () => {
    let newtext =''
    setText(newtext);
  };
  const handleUpperChange4 = () => {
    let newtext = text.split(/[ ]+/)
    setText(newtext.join());
  };
  const handleUpperChange5 = () => {
    let newtext = document.getElementById("mybox");
    newtext.select();
    navigator.clipboard.writeText(newtext.value);
  };


  const wordCount = text.trim().split(/\s+/).length;
  
  return (
    <div className="Blog2">
      <h1>Word Counter</h1>
      <textarea onChange={handleTextChange} value={text} id="mybox" ></textarea>
      <button onClick={handleUpperChange}>toUpperCase</button>
      <button onClick={handleUpperChange2}>toLocaleLowerCase</button>
      <button onClick={handleUpperChange3}>CLEAR </button>
      <button onClick={handleUpperChange4}>join </button>
      <button onClick={handleUpperChange5}>copy</button>
      <p>Word count: {wordCount}</p>
    </div>
  );
}

export default Blog2;

