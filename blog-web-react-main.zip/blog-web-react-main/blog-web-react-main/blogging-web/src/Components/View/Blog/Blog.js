import React from 'react'
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
const Blog = () => {
  var uuid = require('uuid-v4');
 
  // navigate
  const navigate =useNavigate()
  const bkehoe=()=>{
    navigate('/Home')
  }
 


  return (
    // uuid id
    <><h1> {uuid()}</h1>
 <div>
      <h1>Counters that update separately</h1>
      <MyButton />
      <MyButton />
    </div>
     {/* navigate */}
    <button onClick={bkehoe}>home</button>
    </>
  )


function MyButton() {
  const [count, setCount] = useState(0);


  // /redem is not declired  but this work in befor refers
  useEffect(() => {
    alert("cliked me");
  }, []);

  function handleClick() {
    setCount(count + 1);
  }

  return (
    <button onClick={handleClick}>
      Clicked {count} 
    </button>
  );
}
}
export default Blog









