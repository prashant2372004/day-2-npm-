
import React from 'react'
import { useSearchParams } from 'react-router-dom'


function App2() {
  const [searchParams, setSearchParams] = useSearchParams();
  console.warn(searchParams.get('age'))
  console.warn(searchParams.get('city'))
  const age = searchParams.get('age');
  const city = searchParams.get('city')
  return (
    <>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. At nostrum omnis sint perspiciatis dolore maiores iure quis odit corrupti ratione nesciunt ex quod a placeat recusandae esse aliquid necessitatibus iste suscipit voluptas exercitationem, illo assumenda. At et error, voluptatibus maxime aspernatur alias odit ad fugit.
      <button onClick={() => setSearchParams({ age: 10 , city:74})}>er</button>
      <h6>{city}</h6>
      <h6>{age}</h6>

    </>
    
  )
}

export default App2

