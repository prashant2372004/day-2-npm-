import React from 'react'

function app2() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. At nostrum omnis sint perspiciatis dolore maiores iure quis odit corrupti ratione nesciunt ex quod a placeat recusandae esse aliquid necessitatibus iste suscipit voluptas exercitationem, illo assumenda. At et error, voluptatibus maxime aspernatur alias odit ad fugit.
    </div>
  )
}

export default app2
